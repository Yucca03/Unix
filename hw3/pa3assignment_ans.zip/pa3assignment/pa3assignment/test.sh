#!/bin/sh

alias xyz="cd /home/yucca/"

