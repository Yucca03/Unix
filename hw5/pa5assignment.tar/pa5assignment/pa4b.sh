#!/usr/bin/tcsh
set echo
$1:q >& /dev/null
